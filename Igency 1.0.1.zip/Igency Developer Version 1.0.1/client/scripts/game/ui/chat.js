import { settings } from "../../root/settings/settings.js"

import { server } from "../../root/server/server.js"

let chat = {
    enable: function () {
        let chatBar = document.querySelector("#chatbar")
        let chatContent = document.querySelector("#chatcontent")
        chatContent.style.width = settings.game.ui.chat.content.width + "px"
        chatContent.style.height = settings.game.ui.chat.content.height + "px"
        chatContent.style.left = settings.game.ui.chat.content.x + "px"
        chatContent.style.top = settings.game.ui.chat.content.y + "px"
        chatBar.style.width = settings.game.ui.chat.bar.width + "px"
        chatBar.style.height = settings.game.ui.chat.bar.height + "px"
        chatBar.style.left = settings.game.ui.chat.bar.x + "px"
        chatBar.style.top = settings.game.ui.chat.bar.y + "px"
        chatBar.placeholder = settings.game.ui.chat.bar.placeholder
        document.addEventListener("keydown", (event) => {
            if (event.key.toLowerCase() === settings.game.keybinds.sendMessage.toLowerCase()) {
                let message = {
                    type: "sendMessageInChat",
                    data: {
                        id: settings.id,
                        username: settings.game.player.username,
                        message: document.querySelector("#chatbar").value
                    }
                }
                server.send(message)
            }
        })
    }
}

export { chat }