import { data } from "../data/data.js"

import { render } from "../system/render.js"

import { settings } from "../../root/settings/settings.js"

let bullets = {
    render: function () {
        data.bullets.forEach(function (bullet) {
            data.images.forEach(function (image) {
                if (image.id === bullet.id) {
                    data.rules.bullets.forEach(function (object) {
                        if (object.id === bullet.id) {
                            render.image(image, bullet.x, bullet.y, object.width, object.height, bullet.angle)
                        }
                    })
                }
            })
        })
    }
}

export { bullets }