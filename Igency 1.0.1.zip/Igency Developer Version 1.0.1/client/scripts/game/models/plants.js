import { data } from "../data/data.js"

import { render } from "../system/render.js"

let plants = {
    render: function () {
        data.plants.forEach(function (plant) {
            if (plant.type === "tree") {
                data.rules.plants.trees.forEach(function (tree) {
                    if (tree.id === plant.id) {
                        data.images.forEach(function (image) {
                            if (image.id === plant.id && image.id === tree.id) {
                                render.image(image, plant.x, plant.y, tree.width, tree.height, tree.angle)
                            }
                        })
                    }
                })
            }
        })
    }
}

export { plants }