import { settings } from "../../root/settings/settings.js"

let menu = {
    get: function () {
        _("#keybindsup").value = settings.game.keybinds.up
        _("#keybindsdown").value = settings.game.keybinds.down
        _("#keybindsleft").value = settings.game.keybinds.left
        _("#keybindsright").value = settings.game.keybinds.right
        _("#slotone").value = settings.game.keybinds.slots.one
        _("#slottwo").value = settings.game.keybinds.slots.two
        _("#slotthree").value = settings.game.keybinds.slots.three
        _("#slotfour").value = settings.game.keybinds.slots.four
        _("#sendmessage").value = settings.game.keybinds.sendMessage
        _("#togglechat").value = settings.game.keybinds.toggleChat
        _("#quality").value = settings.quality
        function _(element) {
            return document.querySelector(element)
        }
    },
    update: function () {
        let newSettings = settings
        newSettings.game.player.username = _("#username").value
        newSettings.game.keybinds.up = _("#keybindsup").value
        newSettings.game.keybinds.down = _("#keybindsdown").value
        newSettings.game.keybinds.left = _("#keybindsleft").value
        newSettings.game.keybinds.right = _("#keybindsright").value
        newSettings.game.keybinds.slots.one = _("#slotone").value
        newSettings.game.keybinds.slots.two = _("#slottwo").value
        newSettings.game.keybinds.slots.three = _("#slotthree").value
        newSettings.game.keybinds.slots.four = _("#slotfour").value
        newSettings.game.keybinds.sendMessage = _("#sendmessage").value
        newSettings.game.keybinds.toggleChat = _("#togglechat").value
        newSettings.quality = _("#quality").value
        window.innerWidth = settings.window.width * settings.quality
        window.innerHeight = settings.window.height * settings.quality
        _("#game").width = window.innerWidth
        _("#game").height = window.innerHeight
        settings.$(newSettings)
        console.log(settings)
        function _(element) {
            return document.querySelector(element)
        }

    }
}

export { menu }