import { game } from "../../game/game.js"

import { menu } from "./menu.js"

import { settings } from "../../root/settings/settings.js"

let buttons = {
    active: function () {
        _("#play").onclick = () => {
            menu.get()
            menu.update()
            game.run()
        }
        _("#settings").onclick = () => {
            _("#menu").style.display = "block"
            _("#settingsmenu").style.display = "grid"
            menu.get()
        }
        _("#github").onclick = () => {
            window.open(settings.github)
        }
        _("#discord").onclick = () => {
            window.open(settings.discord)
        }
        _("#menuclose").onclick = () => {
            _("#menu").style.display = "none"
            _("#settingsmenu").style.display = "none"
            menu.update()
        }
        function _(css) {
            return document.querySelector(css)
        }
    }
}

export { buttons }