import { root } from "./root/root.js"

import { game } from "./game/game.js"

import { home } from "./home/home.js"