let definitions = {
    player: {
        type: "player",
        id: "player",
        username: null,
        status: "alive",
        roles: [],
        skin: {
            body: null,
            hands: {
                left: null,
                right: null
            }
        },
        slots: [],
        ammo: [],
        health: 100,
        angle: 0,
        hit: false,
        hitlock: true,
        hitside: "both",
        direction: [],
        body: {
            x: null,
            y: null
        },
        hands: {
            hitTimer: null,
            left: {
                x: null,
                y: null
            },
            right: {
                x: null,
                y: null
            }
        }
    },
    weapons: {
        melees: [
            {
                type: "melee",
                id: "hands",
                health: 1000,
                status: "alive",
                damage: 5,
                stack: 1,
                speed: 1,
                hit: "stab",
                atPosition: ["left", "right"],
                hitbox: {
                    width: 27,
                    health: 27,
                    offsetX: 0,
                    offsetY: 0,
                    angle: 0
                }
            },
            {
                type: "melee",
                id: "knife",
                health: 1000,
                status: "alive",
                damage: 7,
                stack: 1,
                speed: 1,
                hit: "stab",
                atPosition: ["right"],
                hitbox: {
                    width: 30,
                    height: 70,
                    offsetX: 10,
                    offsetY: 20,
                    angle: - (Math.PI * 1.2)
                }
            },
            {
                type: "melee",
                id: "dagger",
                health: 1000,
                status: "alive",
                damage: 8,
                stack: 1,
                speed: 2,
                hit: "whirl",
                atPosition: ["right"],
                hitbox: {
                    width: 24,
                    height: 80,
                    offsetX: 10,
                    offsetY: 20,
                    angle: - (Math.PI * 0.2 + Math.PI)
                }
            },
            {
                type: "melee",
                id: "long_sword",
                health: 1000,
                status: "alive",
                damage: 15,
                stack: 1,
                speed: 2,
                hit: "whirl",
                atPosition: ["right"],
                hitbox: {
                    width: 40,
                    height: 150,
                    offsetX: 25,
                    offsetY: 40,
                    angle: - (Math.PI * 0.2 + Math.PI)
                }
            }
        ],
        guns: [
            {
                type: "gun",
                id: "vector",
                bullet: "9mm",
                health: 1000,
                status: "alive",
                damage: 2,
                capacity: 50,
                accuracy: 1,
                speed: 3,
                spreadingAngle: 20,
                bulletCount: 1,
                reloadTime: 2000,
                range: 5 * 300,
                duration: 50,
                stack: 1,
                atPosition: ["center"],
                hitbox: {
                    width: 20,
                    height: 100,
                    offsetX: 0,
                    offsetY: 75,
                    angle: Math.PI
                }
            }
        ]
    },
    bullets: [
        {
            type: "bullet",
            id: "9mm",
            health: 10,
            status: "alive",
            damage: 3,
            rangeDone: null,
            newBulletDelay: null,
            hitbox: {
                width: 8,
                height: 20,
                offsetX: 0,
                offsetY: 0,
                angle: Math.PI
            }
        }
    ],
    plants: {
        trees: [
            {
                type: "tree",
                id: "oak",
                health: 25,
                status: "alive",
                damage: 5,
                spawnRate: 20,
                spawnGroup: 2,
                spawnGroupRate: 20,
                hitbox: {
                    width: 300,
                    height: 300,
                    offsetX: 0,
                    offsetY: 0,
                    angle: 0
                }
            }
        ]
    }
}

module.exports = definitions