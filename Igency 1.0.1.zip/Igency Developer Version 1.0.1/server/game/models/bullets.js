let data = require("../data/data.js")

let definitions = require("../definitions/definitions.js")

let bullets = {
    calculatePositions: function () {
        data.players.forEach(function (player) {
            player.slots.forEach(function (weapon) {
                data.bullets.forEach(function (bullet) {
                    bullet.newBulletDelay++
                    if (bullet.status === "dead") {
                        let newBullets = []
                        data.bullets.forEach(function (oldBullet) {
                            if (oldBullet.status !== "dead") {
                                newBullets.push(oldBullet)
                            }
                        })
                        data.bullets = newBullets
                    }
                    definitions.weapons.guns.forEach(function (gun) {
                        if (gun.id === bullet.gun) {
                    		let radians = bullet.angle + Math.PI * 1.5
                    		let distance = gun.speed
                    		bullet.x = bullet.x + Math.cos(radians) * distance
                    		bullet.y = bullet.y + Math.sin(radians) * distance
                            bullet.rangeDone = bullet.rangeDone + distance
                            if (bullet.rangeDone >= gun.range) {
                                bullet.status = "dead"
                            }
                        }
                    })
                })
                if (weapon.selected === true && weapon.type === "gun" && weapon.active === true) {
                    let stopProcess = false
                    data.bullets.forEach(function (bullet) {
                        definitions.weapons.guns.forEach(function (gun) {
                        	if (bullet.from === player.id && bullet.newBulletDelay < gun.duration) {
                                stopProcess = true
                        	}
                        })
                    })
                    if (stopProcess === true) {
                        return
                    }
                    let bullet = {
                        type: "bullet",
                        id: weapon.bullet,
                        gun: weapon.id,
                        from: player.id,
                        newBulletDelay: 0,
                        rangeDone: 0,
                        x: null,
                        y: null,
                        angle: null
                    }
                    if (weapon.atPosition.includes("center") === true) {
                        definitions.weapons.guns.forEach(function (gun) {
                            definitions.bullets.forEach( function (object) {
                            	if (gun.id === weapon.id && object.id === gun.bullet) {
                                	let bulletDistance = Math.sqrt(Math.pow(gun.hitbox.offsetX, 2) + Math.pow(gun.hitbox.offsetY + gun.hitbox.height, 2))
                                	let bulletAngle = Math.atan2(gun.hitbox.offsetY + gun.hitbox.height, gun.hitbox.offsetX)
                                	bullet.x = player.body.x + Math.cos(player.angle + bulletAngle) * bulletDistance
                                	bullet.y = player.body.y + Math.sin(player.angle + bulletAngle) * bulletDistance
                                	bullet.angle = player.angle + object.hitbox.angle
                                	data.bullets.push(bullet)
                            	}
                            })
                        })
                    }
                }
            })
        })
    }
}

module.exports = bullets