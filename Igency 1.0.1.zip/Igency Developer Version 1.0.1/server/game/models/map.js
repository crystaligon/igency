let data = require("../data/data.js")

let definitions = require("../definitions/definitions.js")

let probability = require("../system/probability.js")

let map = {
    generate: function () {
        for (let x = 0; x < data.map.length; x++) {
            for (let y = 0; y < data.map[x].length; y++) {
                definitions.plants.trees.forEach(function (tree) {
                    data.rules.plants.trees.forEach(function (plant) {
                    	if (tree.id === plant.id && probability(tree.spawnRate) === true) {
                        	let object = {
                            	type: tree.type,
                             	id: tree.id,
                             	x: getRandomPosition(x * data.rules.map.tiles.size + data.rules.map.tiles.size - tree.hitbox.width, x * data.rules.map.tiles.size),
                             	y: getRandomPosition(y * data.rules.map.tiles.size + data.rules.map.tiles.size - tree.hitbox.height, y * data.rules.map.tiles.size)
                        	}
							data.plants.push(object)
							if (tree.spawnGroup !== 0) {
								for (let a = 0; a < tree.spawnGroup; a++) {
									if (probability(tree.spawnGroupRate) === true) {
										let newObject = {
											type: tree.type,
											id: tree.id,
											x: getRandomPosition(object.x - tree.hitbox.width, object.x + tree.hitbox.width),
											y: getRandomPosition(object.y - tree.hitbox.height, object.y + tree.hitbox.height)
										}
										data.plants.push(newObject)
									}
								}
							}
                        	function getRandomPosition(min, max) {
                            	return Math.floor(Math.random() * (max - min + 1)) + min
                        	}
                    	}
                    })
                })
            }
        }
    }
}

module.exports = map