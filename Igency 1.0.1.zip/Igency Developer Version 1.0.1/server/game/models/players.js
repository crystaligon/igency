let data = require("../data/data.js")

let probability = require("../system/probability.js")

let definitions = require("../definitions/definitions.js")

let players = {
    toggleHit: function () {
        data.players.forEach(function (object) {
            if (object.hands.hitTimer === null) {
                object.hands.hitTimer = data.rules.players.hands.hitSpeed
                return
            }
            if (object.hands.hitTimer >= 0) {
                object.hands.hitTimer--
                return
            }
            if (object.hands.hitTimer <= 0) {
                object.hands.hitTimer = data.rules.players.hands.hitSpeed
            }
            object.hitlock = !object.hitlock
            if (probability(30) === true) {
                object.hitside = "left"
            }
            else if (probability(30) === true) {
                object.hitside = "right"
            }
            else {
                object.hitside = "both"
            }
        })
    },
    calculateSlots: function () {
        data.players.forEach(function (player) {
            if (player.slots.selected === 1) {
                player.slots.active = player.slots.one
            }
            if (player.slots.selected === 2) {
                player.slots.active = player.slots.two
            }
            if (player.slots.selected === 3) {
                player.slots.active = player.slots.three
            }
            if (player.slots.selected === 4) {
                player.slots.active = player.slots.four
            }
        })
    },
    calculateHands: function () {
        data.players.forEach(function (player) {
            let forceCustomPosition = {
                active: false,
                type: null
            }
            player.slots.forEach(function (weapon) {
                if (weapon.selected === true && weapon.type === "gun") {
                    definitions.weapons.guns.forEach(function (gun) {
                        if (weapon.id === gun.id && gun.atPosition.includes("center") === true) {
                            forceCustomPosition.active = true
                            forceCustomPosition.type = "gun"
                        }
                    })
                }
            })
            let hitRange = {
                left: 0,
                right: 0
            }
            if (forceCustomPosition.active === true) {
                if (forceCustomPosition.type === "gun") {
                    let leftHandDistance = Math.sqrt(Math.pow(data.rules.players.hands.customPositions.guns.left.x, 2) + Math.pow(data.rules.players.hands.customPositions.guns.left.y, 2))
            		let rightHandDistance = Math.sqrt(Math.pow(data.rules.players.hands.customPositions.guns.right.x, 2) + Math.pow(data.rules.players.hands.customPositions.guns.right.y, 2))
            		let leftHandAngle = Math.atan2(data.rules.players.hands.customPositions.guns.left.y, data.rules.players.hands.customPositions.guns.left.x)
            		let rightHandAngle = Math.atan2(data.rules.players.hands.customPositions.guns.right.y, data.rules.players.hands.customPositions.guns.right.x)
            		player.hands.left.x = player.body.x + Math.cos(player.angle + leftHandAngle) * leftHandDistance
            		player.hands.left.y = player.body.y + Math.sin(player.angle + leftHandAngle) * leftHandDistance
            		player.hands.right.x = player.body.x + Math.cos(player.angle + rightHandAngle) * rightHandDistance
            		player.hands.right.y = player.body.y + Math.sin(player.angle + rightHandAngle) * rightHandDistance
                    return
                }
            }
            if (player.hitlock === false && player.hit === true && forceCustomPosition.active === false) {
                let blockHit = false
                player.slots.forEach(function (weapon) {
                    definitions.weapons.melees.forEach(function (melee) {
                        if (weapon.id === melee.id && weapon.selected === true && melee.hit !== "stab") {
                            blockHit = true
                        }
                    })
                })
                if (player.hitside === "both" && blockHit === false) {
                    hitRange.left = data.rules.players.hands.hitRange
                    hitRange.right = data.rules.players.hands.hitRange
                }
                if (player.hitside === "left" && blockHit === false) {
                    hitRange.left = data.rules.players.hands.hitRange
                }
                if (player.hitside === "right" && blockHit === false) {
                    hitRange.right = data.rules.players.hands.hitRange
                }
            }
            let leftHandDistance = Math.sqrt(Math.pow(data.rules.players.hands.left.offset.x, 2) + Math.pow(data.rules.players.hands.left.offset.y + hitRange.left, 2))
            let rightHandDistance = Math.sqrt(Math.pow(data.rules.players.hands.right.offset.x, 2) + Math.pow(data.rules.players.hands.right.offset.y + hitRange.right, 2))
            let leftHandAngle = Math.atan2(data.rules.players.hands.left.offset.y + hitRange.left, data.rules.players.hands.left.offset.x)
            let rightHandAngle = Math.atan2(data.rules.players.hands.right.offset.y + hitRange.right, data.rules.players.hands.right.offset.x)
            player.hands.left.x = player.body.x + Math.cos(player.angle + leftHandAngle) * leftHandDistance
            player.hands.left.y = player.body.y + Math.sin(player.angle + leftHandAngle) * leftHandDistance
            player.hands.right.x = player.body.x + Math.cos(player.angle + rightHandAngle) * rightHandDistance
            player.hands.right.y = player.body.y + Math.sin(player.angle + rightHandAngle) * rightHandDistance
        })
    },
    move: function () {
        data.players.forEach(function (object) {
            object.direction.forEach(function (angle) {
                let diagonalLength = 1
                if (object.direction.length >= 2) {
                    diagonalLength = 1.3
                }
            	let radians = angle * (Math.PI / 180)
            	let distance = data.rules.players.speed
            	object.body.x = object.body.x + Math.cos(radians) * distance / diagonalLength
            	object.body.y = object.body.y + Math.sin(radians) * distance / diagonalLength
            	if (object.body.x - data.rules.players.body.size / 2 <= 0) {
                	object.body.x = 0 + data.rules.players.body.size / 2
            	}
            	if (object.body.y - data.rules.players.body.size / 2 <= 0) {
                	object.body.y = 0 + data.rules.players.body.size / 2
            	}
            	if (object.body.x + data.rules.players.body.size / 2 >= data.map.length * data.rules.map.tiles.size) {
                	object.body.x = data.map.length * data.rules.map.tiles.size - data.rules.players.body.size / 2
            	}
            	if (object.body.y + data.rules.players.body.size / 2 >= data.map[0].length * data.rules.map.tiles.size) {
                	object.body.y = data.map[0].length * data.rules.map.tiles.size - data.rules.players.body.size / 2
            	}
            })
        })
    }
}

module.exports = players