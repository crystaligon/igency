let data = {
    tick: 16,
    map: [
        [0, 0, 0, 0, 0, 0],
        [0, 0, 0, 0, 0, 0],
        [0, 0, 0, 0, 0, 0],
        [0, 0, 0, 0, 0, 0],
        [0, 0, 0, 0, 0, 0],
        [0, 0, 0, 0, 0, 0]
    ],
    players: [],
    bullets: [],
    buildings: [],
    plants: [],
    rules: {
        players: {
            speed: 6,
            body: {
                size: 70
            },
            hands: {
                hitSpeed: 8,
                hitRange: 5,
                left: {
                    size: 27,
                    offset: {
                        x: 25,
                        y: 30
                    }
                },
                right: {
                    size: 27,
                    offset: {
                        x: - 25,
                        y: 30
                    }
                },
                customPositions: {
                    guns: {
                        left: {
                            x: - 5,
                            y: 30,
                        },
                        right: {
                            x: - 5,
                            y: 55
                        }
                    }
                }
            }
        },
        weapons: {
            melees: [
                {
                    type: "melee",
                    id: "hands",
                    slot: "hands_slot",
                    loot: "hands_loot",
                    atPosition: ["left", "right"],
                    offsetX: 0,
                    offsetY: 0,
                    width: 27,
                    height: 27,
                    angle: 0,
                    distance: 0
                },
                {
                    type: "melee",
                    id: "knife",
                    slot: "knife_slot",
                    loot: "knife_loot",
                    atPosition: ["right"],
                    offsetX: 10,
                    offsetY: 20,
                    width: 37,
                    height: 80,
                    angle:  - (Math.PI * 1.2),
                    distance: 0
                },
                {
                    type: "melee",
                    id: "dagger",
                    slot: "dagger_slot",
                    loot: "dagger_loot",
                    atPosition: ["right"],
                    offsetX: 10,
                    offsetY: 20,
                    width: 24,
                    height: 80,
                    angle: - (Math.PI * 0.2),
                    distance: 0
                },
                {
                    type: "melee",
                    id: "long_sword",
                    slot: "long_sword_slot",
                    loot: "long_sword_loot",
                    atPosition: ["right"],
                    offsetX: 25,
                    offsetY: 40,
                    width: 40,
                    height: 150,
                    angle: - (Math.PI * 0.2 + Math.PI),
                    distance: 0
                }
            ],
            guns: [
                {
                    type: "gun",
                    id: "vector",
                    slot: "vector_slot",
                    loot: "vector_loot",
                    bullet: "9mm",
                    atPosition: ["center"],
                    offsetX: 0,
                    offsetY: 75,
                    width: 20,
                    height: 100,
                    angle: Math.PI,
                    distance: 0
                }
            ]
        },
        bullets: [
            {
                type: "bullet",
                id: "9mm",
                loot: "9mm_loot",
                offsetX: 0,
                offsetY: 0,
                width: 8,
                height: 20,
                angle: Math.PI,
                distance: 0
            }
        ],
        plants: {
            trees: [
                {
                    type: "tree",
                    id: "oak",
                    width: 300,
                    height: 300
                }
            ]
        },
        map: {
            tiles: {
                size: 400
            }
        }
    }
}

module.exports = data