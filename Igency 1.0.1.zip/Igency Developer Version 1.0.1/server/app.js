try {
	let root = require("./root/root.js")
	let game = require("./game/game.js")
} catch (error) {
    console.error("An error occurred:", error.message)
    console.error("Stack trace:", error.stack)
    let stackLines = error.stack.split('\n')
    if (stackLines.length >= 3) {
        let errorLocation = stackLines[2].trim().replace("at ", "")
        console.error("Error location:", errorLocation)
    }
}