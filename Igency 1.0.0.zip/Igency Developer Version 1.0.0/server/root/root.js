let client = require("./client/client.js")
let settings = require("./settings/settings.js")

let root = {}

module.exports = root