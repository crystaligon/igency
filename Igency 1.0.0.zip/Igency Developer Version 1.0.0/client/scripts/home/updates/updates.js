let updates = [
    {
        version: "1.0.0 Beta",
        features: ["- Uploaded first game version"]
    },
    {
        version: "1.0.1 Beta",
        features: ["- Added home screen design","- Added settings", "Added melee weapons", "- Added slot switch", "- Improved rendering"]
    }
]

export { updates }