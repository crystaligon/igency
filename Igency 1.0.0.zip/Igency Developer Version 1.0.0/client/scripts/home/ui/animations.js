let animations = {
    activate: function () {
        let icons = document.getElementsByClassName("designAlphaDynamic")
        for (let i = 0; i < icons.length; i++) {
            icons[i].addEventListener("click", () => {})
        }
    }
}

export { animations }