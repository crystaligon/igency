import { server } from "./server/server.js"

import { settings } from "./settings/settings.js"

let root = {}

export { root }