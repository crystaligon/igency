import { settings } from "../../root/settings/settings.js"

let updates = {
    log: (function () {
        console.log(`%c[updates.js] Running Game Version ${settings.version}`, "color: #d24dff")
    })()
}

export { updates }