import { updates } from "./updates/updates.js"

let home = {}

export { home }