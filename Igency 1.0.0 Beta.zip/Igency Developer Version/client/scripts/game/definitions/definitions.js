import { settings } from "../../root/settings/settings.js"

let definitions = {
    ui: {
        joysticks: [
            {
                type: "joystick",
                id: "joystick_base",
                src: `packages/${settings.package}/images/game/ui/joysticks/joystick_base.svg`
            },
            {
                type: "joystick",
                id: "joystick_stick",
                src: `packages/${settings.package}/images/game/ui//joysticks/joystick_stick.svg`
            }
        ],
        healthbar: [
            {
                type: "healthbar",
                id: "healthbar_base",
                src: `packages/${settings.package}/images/game/ui/healthbar/healthbar_base.svg`
            },
            {
                type: "healthbar",
                id: "healthbar_detail",
                src: `packages/${settings.package}/images/game/ui/healthbar/healthbar_detail.svg`
            }
        ],
        slots: {
            system: [
                {
                    type: "system",
                    id: "empty_slot",
                    src: `packages/${settings.package}/images/game/ui/slots/system/empty_slot.svg`
                }
            ],
            weapons: {
                melees: [
                    {
                        type: "melee",
                        id: "hands_slot",
                        src: `packages/${settings.package}/images/game/ui/slots/weapons/melees/hands_slot.svg`
                    },
                    {
                        type: "melee",
                        id: "knife_slot",
                        src: `packages/${settings.package}/images/game/ui/slots/weapons/melees/knife_slot.svg`
                    },
                    {
                        type: "melee",
                        id: "dagger_slot",
                        src: `packages/${settings.package}/images/game/ui/slots/weapons/melees/dagger_slot.svg`
                    }
                ]
            }
        }
    },
    skins: [
        {
            type: "skin",
            id: "default_body",
            src: `packages/${settings.package}/images/game/skins/default_body.svg`
        },
        {
            type: "skin",
            id: "default_hand_left",
            src: `packages/${settings.package}/images/game/skins/default_hand_left.svg`
        },
        {
            type: "skin",
            id: "default_hand_right",
            src: `packages/${settings.package}/images/game/skins/default_hand_right.svg`
        }
    ],
    weapons: {
        melees: [
            {
                type: "melee",
                id: "hands",
                src: `packages/${settings.package}/images/game/weapons/melees/hands.svg`
            },
            {
                type: "melee",
                id: "knife",
                src: `packages/${settings.package}/images/game/weapons/melees/knife.svg`
            },
            {
                type: "melee",
                id: "dagger",
                src: `packages/${settings.package}/images/game/weapons/melees/dagger.svg`
            }
        ]
    },
    map: {
        tiles: [
            {
                type: "tile",
                id: "grass_tile",
                src: `packages/${settings.package}/images/game/map/tiles/grass.svg`
            }
        ]
    }
}

export { definitions }