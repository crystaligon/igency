import { data } from "../data/data.js"

import { settings } from "../../root/settings/settings.js"

import { render } from "../system/render.js"

let slots = {
    render: function () {
        data.players.forEach(function (object) {
            if (object.id === settings.id) {
                let selectedSlot = object.slots.selected
                let slots = {
                    one: null,
                    two: null,
                    three: null,
                    four: null
                }
                data.rules.weapons.melees.forEach(function (melee) {
                    if (object.slots.one !== null) {
                        if (melee.id === object.slots.one.id) {
                        	slots.one = melee
                    	}
                    }
                    if (object.slots.two !== null) {
                        if (melee.id === object.slots.two.id && object.slots.two) {
                        	slots.two = melee
                    	}
                    }
                    if (object.slots.three !== null) {
                    	if (melee.id === object.slots.three.id) {
                        	slots.three = melee
                    	}
                    }
                    if (object.slots.four !== null) {
                    	if (melee.id === object.slots.four.id) {
                        	slots.four = melee
                    	}
                    }
                })
                data.images.forEach(function (image) {
                    if (slots.one !== null) {
                        if (image.id === slots.one.slot) {
                        	render.image(image, settings.game.ui.slots.one.x * settings.quality, settings.game.ui.slots.one.y * settings.quality, settings.game.ui.slots.one.width * settings.quality, settings.game.ui.slots.one.height * settings.quality, null, true, true)
                    	}
                    }
                    if (slots.two !== null) {
                    	if (image.id === slots.two.slot) {
                        	render.image(image, settings.game.ui.slots.two.x * settings.quality, settings.game.ui.slots.two.y * settings.quality, settings.game.ui.slots.two.width * settings.quality, settings.game.ui.slots.two.height * settings.quality, null, true, true)
                    	}
                    }
                    if (slots.three !== null) {
                    	if (image.id === slots.three.slot) {
                        	render.image(image, settings.game.ui.slots.three.x * settings.quality, settings.game.ui.slots.three.y * settings.quality, settings.game.ui.slots.three.width * settings.quality, settings.game.ui.slots.three.height * settings.quality, null, true, true)
                    	}
                    }
                    if (slots.four !== null) {
                    	if (image.id === slots.four.slot) {
                        	render.image(image, settings.game.ui.slots.four.x * settings.quality, settings.game.ui.slots.four.y * settings.quality, settings.game.ui.slots.four.width * settings.quality, settings.game.ui.slots.four.height * settings.quality, null, true, true)
                    	}
                    }
                })
            }
        })
    }
}

export { slots }