import { data } from "../data/data.js"

import { settings } from "../../root/settings/settings.js"

import { definitions } from "../definitions/definitions.js"

import { render } from "../system/render.js"

let weapons = {
    render: function () {
        data.players.forEach(function (player) {
        	data.images.forEach(function (image) {
            	if (image.id === player.weapon.texture) {
                    if (player.weapon.left.x !== null && player.weapon.left.y !== null) {
                        render.image(image, player.weapon.left.x, player.weapon.left.y, player.weapon.width, player.weapon.height, player.angle + player.weapon.left.angle)
                    }
                    if (player.weapon.right.x !== null && player.weapon.right.y !== null) {
                        render.image(image, player.weapon.right.x, player.weapon.right.y, player.weapon.width, player.weapon.height, player.angle + player.weapon.right.angle)
                    }
                }
        	})
        })
    }
}

export { weapons }