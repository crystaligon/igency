let definitions = {
    player: {
        type: "player",
        id: "player",
        username: null,
        status: "alive",
        roles: [],
        skin: {
            body: null,
            hands: {
                left: null,
                right: null
            }
        },
        slots: {
            active: null,
            selected: 1,
            one: null,
            two: null,
            three: null,
            four: null
        },
        weapon: {
            texture: null,
            width: null,
            height: null,
            left: {
                angle: null,
                x: null,
                y: null
            },
            right: {
                angle: null,
                x: null,
                y: null
            }
        },
        ammo: {},
        health: 100,
        angle: 0,
        hit: false,
        hitlock: true,
        hitside: "both",
        direction: [],
        body: {
            x: null,
            y: null
        },
        hands: {
            left: {
                x: null,
                y: null
            },
            right: {
                x: null,
                y: null
            }
        }
    },
    weapons: {
        melees: [
            {
                type: "melee",
                id: "hands",
                damage: 5,
                dropped: false,
                stack: 1,
                twoHanded: false,
                bothHands: true,
                pair: true,
                ammo: false,
                speed: false,
                range: false
            },
            {
                type: "melee",
                id: "knife",
                damage: 7,
                dropped: true,
                stack: 1,
                twoHanded: false,
                bothHands: false,
                pair: false,
                ammo: false,
                speed: false,
                range: false
            },
            {
                type: "melee",
                id: "dagger",
                damage: 8,
                dropped: true,
                stack: 1,
                twoHanded: false,
                bothHands: true,
                pair: true,
                ammo: false,
                speed: false,
                range: false
            }
        ]
    }
}

module.exports = definitions