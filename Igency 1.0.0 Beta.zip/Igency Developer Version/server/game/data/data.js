let data = {
    map: [
        [0, 0, 0, 0, 0, 0],
        [0, 0, 0, 0, 0, 0],
        [0, 0, 0, 0, 0, 0],
        [0, 0, 0, 0, 0, 0],
        [0, 0, 0, 0, 0, 0],
        [0, 0, 0, 0, 0, 0]
    ],
    players: [],
    bullets: [],
    buildings: [],
    plants: [],
    rules: {
        players: {
            speed: 1.7,
            body: {
                size: 70
            },
            hands: {
                hitSpeed: 150,
                hitRange: 5,
                left: {
                    size: 27,
                    offset: {
                        x: 25,
                        y: 30
                    }
                },
                right: {
                    size: 27,
                    offset: {
                        x: - 25,
                        y: 30
                    }
                }
            }
        },
        weapons: {
            melees: [
                {
                    type: "melee",
                    id: "hands",
                    slot: "hands_slot",
                    loot: "hands_loot",
                    offsetX: 0,
                    offsetY: 0,
                    width: 27,
                    height: 27,
                    angle: 0,
                    distance: 0
                },
                {
                    type: "melee",
                    id: "knife",
                    slot: "knife_slot",
                    loot: "knife_loot",
                    offsetX: 10,
                    offsetY: 20,
                    width: 37,
                    height: 80,
                    angle:  - (Math.PI * 1.2),
                    distance: 0
                },
                {
                    type: "melee",
                    id: "dagger",
                    slot: "dagger_slot",
                    loot: "dagger_loot",
                    offsetX: 10,
                    offsetY: 20,
                    width: 24,
                    height: 80,
                    angle: - (Math.PI * 0.2),
                    distance: 0
                }
            ]
        },
        map: {
            tiles: {
                size: 400
            }
        }
    }
}

module.exports = data