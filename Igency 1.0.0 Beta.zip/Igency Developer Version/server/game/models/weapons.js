let data = require("../data/data.js")

let weapons = {
    calculatePositions: function () {
        data.players.forEach(function (player) {
            data.rules.weapons.melees.forEach(function (object) {
                if (object.id === player.slots.active.id && player.slots.active.bothHands === false && object.type === "melee") {
                    let weaponDistance = Math.sqrt(Math.pow(object.offsetX, 2) + Math.pow(object.offsetY, 2))
            		let weaponAngle = Math.atan2(object.offsetY, object.offsetX)
                    let newX = player.hands.right.x + Math.cos(player.angle + weaponAngle) * weaponDistance
            		let newY = player.hands.right.y + Math.sin(player.angle + weaponAngle) * weaponDistance
                    player.weapon.texture = object.id
                    player.weapon.width = object.width
                    player.weapon.height = object.height
                    player.weapon.right.x = newX
                    player.weapon.right.y = newY
                    player.weapon.left.x = null
                    player.weapon.left.y = null
                    player.weapon.right.angle = object.angle
                    player.weapon.left.angle = null
                }
        		if (object.id === player.slots.active.id && player.slots.active.bothHands === true && object.type === "melee") {
          		  	let leftWeaponDistance = Math.sqrt(Math.pow(object.offsetX, 2) + Math.pow(object.offsetY, 2))
            		let rightWeaponDistance = Math.sqrt(Math.pow(object.offsetX, 2) + Math.pow(object.offsetY, 2))
            		let leftWeaponAngle = Math.atan2(object.offsetY, - object.offsetX)
            		let rightWeaponAngle = Math.atan2(object.offsetY, object.offsetX)
            		let newLeftX = player.hands.left.x + Math.cos(player.angle + leftWeaponAngle) * leftWeaponDistance
            		let newLeftY = player.hands.left.y + Math.sin(player.angle + leftWeaponAngle) * leftWeaponDistance
            		let newRightX = player.hands.right.x + Math.cos(player.angle + rightWeaponAngle) * rightWeaponDistance
          		  	let newRightY = player.hands.right.y + Math.sin(player.angle + rightWeaponAngle) * rightWeaponDistance
                    player.weapon.texture = object.id
                    player.weapon.width = object.width
                    player.weapon.height = object.height
                    player.weapon.left.x = newLeftX
                    player.weapon.left.y = newLeftY
                    player.weapon.right.x = newRightX
                    player.weapon.right.y = newRightY
                    player.weapon.left.angle = - object.angle
                    player.weapon.right.angle = object.angle
        		}
        	})
        })
    }
}

module.exports = weapons